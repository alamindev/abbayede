<template>
  <main>
    <CommonNewsBanner />  
    <NewsMainArea />  
    <NewsInfoArea />  
  </main>
</template>

<script>
export default {
  name: "News",
  data() {
    return {
    
    };
  },
};
</script>
