<template>
  <main>
    <CommonNewsBanner />  
    <NewsDetailsMainArea />   
  </main>
</template>

<script>
export default {
  name: "NewsDetails",
  data() {
    return {
    
    };
  },
};
</script>
