<template>
  <main>
    <ArchivesBanner />  
    <ArchivesNav />  
    <ArchivesMission />  
    <ArchivesDocument />  
    <ArchivesAccordions />  
    <ArchivesEvents />  
    <ArchivesInfoArea />  
  
  </main>
</template>

<script>
export default {
  name: "Archives",
  data() {
    return {
    
    };
  },
};
</script>
