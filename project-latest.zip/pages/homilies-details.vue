<template>
  <main>
    <HomiliesBanner />    
    <HomiliesDetailsMainArea />    
  </main>
</template>

<script>
export default {
  name: "HistoryDetails",
  data() {
    return {
    
    };
  },
};
</script>
