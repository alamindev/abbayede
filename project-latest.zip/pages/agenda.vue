<template>
  <main>
    <CommonAgendaBanner /> 
    <AgendaNav />  
    <CommonBlog />  
    <AgendaInfo />  
  </main>
</template>

<script>
export default {
  name: "Agenda",
  data() {
    return {
    
    };
  },
};
</script>
