<template>
  <main>
    <FoundationBanner />  
    <FoundationNav />  
    <FoundationMission />   
    <FoundationProject />   
    <FoundationAims />   
    <FoundationGallary />   
    <FoundationInfoArea />   
  </main>
</template>

<script>
export default {
  name: "Foundation",
  data() {
    return {
    
    };
  },
};
</script>
