<template>
  <main>
    <HomiliesBanner />   
    <HomiliesNav />   
    <HomiliesMainArea />   
    <AgendaInfo />   
  </main>
</template>

<script>
export default {
  name: "Homilies",
  data() {
    return {
    
    };
  },
};
</script>
