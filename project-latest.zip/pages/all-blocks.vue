<template>
  <main>
    <AllBlocksBanner />  
    <HomeWelcomeAbbay /> 
    <AllBlocksEngraving /> 
    <AllBlocksTextBlock /> 
    <AllBlocksHightlight /> 
    <AllBlocksColorFull /> 
    <AllBlocksDescription /> 
    <AllBlocksDescriptionTwo /> 
    <AllBlocksMap /> 
    <AllBlocksImages /> 
    <ArchivesAccordions />  
    <AllBlocksDownload />  
    <HomeNews /> 
    <HomePrepareVisit /> 
    <div class="space-y-10 md:space-y-20 xl:space-y-28 pt-8 sm:pt-14 lg:pt-20">
      <HomeFeaturedEvent /> 
      <HomeAgenda /> 
      <CommonBlog />   
    </div>
     <HomeCommunity /> 
     <AllBlocksMassTimes /> 
      <HomeAroundTheAbby /> 
    <div class="  sm:py-14 lg:py-20 md:space-y-14">
      <FoundationProject /> 
      <FoundationAims />     
    </div>
    <AllBlocksBlogs/>
    <AgendaDetailsGallary />   
    <div class="space-y-8 md:space-y-14 lg:space-y-24 mt-8 sm:pt-14 lg:mt-20 xl:mt-24">
        <FoundationInfoArea />   
        <HomeHistory /> 
        <AllBlocksPublication /> 
        <HomeNewsLetter /> 
    </div>
  </main>
</template>

<script>
export default {
  name: "AllBlocks",
  data() {
    return {
    
    };
  },
};
</script>
