<template>
  <main>
    <ConservationBanner />  
    <ConservationNav />  
    <ConservationMission />      
    <ConservationMainArea />   
    <ConservationInfoArea />   
  </main>
</template>

<script>
export default {
  name: "Conservation",
  data() {
    return {
    
    };
  },
};
</script>
