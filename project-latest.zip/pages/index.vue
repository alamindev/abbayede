<template>
  <main>
    <HomeBanner /> 
    <HomeWelcomeAbbay /> 
    <HomeAgenda /> 
    <HomePrepareVisit /> 
    <HomeFeaturedEvent /> 
    <HomeGallary /> 
    <HomeNews /> 
    <HomeCommunity /> 
    <HomeMassTimes /> 
    <HomeAroundTheAbby /> 
    <HomeNewsLetter /> 
    <HomeHistory /> 
  </main>
</template>

<script>
export default {
  name: "IndexPage",
  data() {
    return {
    
    };
  },
};
</script>
