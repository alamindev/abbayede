<template>
  <main>
    <ConservationBanner />  
    <ConservationNav />      
    <ConservationProjectMainArea />   
    <ConservationInfoArea />   
  </main>
</template>

<script>
export default {
  name: "Conservation",
  data() {
    return {
    
    };
  },
};
</script>
