<template>
  <main>
    <FoundationBanner />  
    <FoundationHaritageNav />  
    <FoundationHaritageMainArea/>
    <FoundationInfoArea />   
  </main>
</template>

<script>
export default {
  name: "FoundationHaritage",
  data() {
    return {
    
    };
  },
};
</script>
