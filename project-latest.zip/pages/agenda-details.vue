<template>
  <main>
    <CommonAgendaBanner />  
    <AgendaDetailsText />  
    <AgendaDetailsImages />  
    <AgendaDetailsInfo />  
    <AgendaDetailsGallary />  
  </main>
</template>

<script>
export default {
  name: "AgendaDetails",
  data() {
    return {
    
    };
  },
};
</script>
