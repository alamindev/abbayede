<template>
  <main>
    <HistoryBanner />   
    <HistoryMission />   
    <HistoryPlaces />   
    <HistoryInfoBox />   
    <HistoryMap />   
    <AgendaInfo />   
  </main>
</template>

<script>
export default {
  name: "History",
  data() {
    return {
    
    };
  },
};
</script>
