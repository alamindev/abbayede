<template>
  <div class="font-montserrat">
    <Header />
    <Nuxt />
    <Footer />
  </div>
</template>
<script>
export default {
  name: "DefaultLayout",

}
</script>