<template>
  <section class="px-4 py-8 lg:py-12 ">
        <div class="max-w-screen-2xl mx-auto">
            <div class="grid lg:grid-cols-12 sm:gap-7">
                <div class="lg:col-start-2 col-span-12 lg:col-span-10 pb-7 md:pb-10 ">
                    <p class="text-sm font-medium text-brand-gray-900 pb-8 sm:pb-14">15.06.2022</p>
                    <h2 class="text-[32px] lg:text-[46px] leading-[1.2] text-dark font-lancelot text-left sm:text-center">Synode 2021-2023 : Pour une Église synodale</h2>
                </div>
                <div class="col-span-12 md:col-span-10 md:col-start-3 lg:col-span-8 lg:col-start-3">
                    <p class="text-base md:text-[19px] text-dark leading-[1.7]">
                        Mettons-nous en marche tous ensemble ! Seul, en famille, entre voisins, en groupes (conseils de communauté, chorales, groupes de prière, scouts, jeunes, mouvements d’action catholique, instances de diaconie, communautés religieuses…) prenons la route avec joie et enthousiasme et marchons tous ensemble sur « le chemin qui mène à l’Église que Dieu nous appelle à être ».
                                                <br><br>
                        <strong>L’écoute et le dialogue seront nos bâtons de marche</strong>
                        <br><br>
                        A l’aide du questionnaire ci-joint qui vous servira de balise sur les sentiers que vous emprunterez, réfléchissez seul ou avec d’autres ! Au fil de vos rencontres, écoutez et dialoguez très librement avec les membres de vos communautés ecclésiales, avec toute personne intéressée, avec ces blessés, ces révoltés qui vous interpelleront peut-être vivement, avec ces croyants d’autres horizons, avec ces pèlerins d’un jour croisés au hasard du chemin et encore plus largement avec tout homme et femme que votre démarche interrogera.
                    </p>
                </div>
                <div class="col-span-12 -mx-4 md:-mx-0 py-10">
                    <div class="aspect-w-16 aspect-h-9">
                        <iframe  src="https://www.youtube.com/embed/3NvgNgwfC9o" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
                <div class="col-span-12 md:col-span-10 md:col-start-3 lg:col-span-8 lg:col-start-3 pb-8">
                    <p class="text-base md:text-[19px] text-dark leading-[1.7]">
                      <strong>Courage, humilité et discernement empliront votre besace</strong>
                        <br><br>
                        Ils vous seront une aide précieuse sur vos chemins. Le courage et l’authenticité de vos paroles seront semences de liberté, de vérité et de charité.
                        <br><br>
                        L’humilité ouvrira votre cœur à la parole de l’autre, ce frère à toujours accueillir.
                        <br><br>
                        Le discernement et l’ouverture seront source de fécondité et de nouveauté « pour construire des communautés florissantes et résilientes pour la mission de l’Église aujourd’hui ».
                        <br><br>
                        <strong>Passez du temps avec l’avenir et faites naître l’espérance.</strong>
                        <br><br>
                        Pour cela un outil concret vous est proposé : un questionnaire. Il est composé d’une série de questions introductives puis de dix thèmes mettant en évidence des aspects significatifs de la « synodalité vécue ».
                        <br><br> 
                        Chacun de ces thèmes est accompagné d’une série de questions aidant à la réflexion.
                        <br><br> 
                        Il ne s’agit pas de répondre à toutes les questions mais de choisir celles qui vous semblent les plus pertinentes pour vous. Vos réponses claires et synthétiques sont à transcrire dans l’encadré correspondant..
                    </p> 
                </div>
                <div class="col-span-12 md:col-span-10 md:col-start-3 lg:col-span-8 lg:col-start-3 flex flex-wrap gap-4 items-center ">
                    <nuxt-link  to="/" class="flex justify-start items-stretch group focus:none" >
                        <svg width="23"  height="44" viewBox="0 0 23 44" class="-mr-[2px] stroke-primary group-hover:fill-primary group-hover:stroke-primary" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M22 42.5L1 36.6227L1 7.74258L22 1.5"  stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
                        </svg>
                        <span class="border-y-2    font-medium text-dark group-hover:text-white bg-transparent group-hover:bg-primary group-hover:border-primary border-primary rounded-sm my-[0.3px] flex justify-center items-center">
                            Télécharger le questionnaire
                            <sup><icon-arrow-top-right></icon-arrow-top-right></sup>
                        </span>
                        <svg width="23" height="44" viewBox="0 0 23 44" class="-ml-[2px] stroke-primary group-hover:fill-primary group-hover:stroke-primary" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 1.5L22 7.37732V36.2574L1 42.5"  stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
                        </svg> 
                    </nuxt-link>
                    <nuxt-link  to="/" class="flex justify-start items-stretch group focus:none" >
                        <svg width="23"  height="44" viewBox="0 0 23 44" class="-mr-[2px] stroke-primary group-hover:fill-primary group-hover:stroke-primary" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M22 42.5L1 36.6227L1 7.74258L22 1.5"  stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
                        </svg>
                        <span class="border-y-2    font-medium text-dark group-hover:text-white bg-transparent group-hover:bg-primary group-hover:border-primary border-primary rounded-sm my-[0.3px] flex justify-center items-center">
                        Questionnaire en ligne
                        <sup> <icon-arrow-top-right></icon-arrow-top-right></sup>
                        </span>
                        <svg width="23" height="44" viewBox="0 0 23 44" class="-ml-[2px] stroke-primary group-hover:fill-primary group-hover:stroke-primary" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 1.5L22 7.37732V36.2574L1 42.5"  stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
                        </svg> 
                    </nuxt-link>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name: 'News',
    data() {
        return { 
            newses: [
                {
                    id: 1,
                    title: 'La Semaine Romande de Musique et de Liturgie',
                    image: '/images/news/news-img-1.png',
                    date: 'Actualité - 16.07.2022'
                },
                {
                    id: 2,
                    title: 'Changement des horaires de visite du Trésor durant la Pentecôte',
                    image: '/images/news/news-img-2.png',
                    date: 'Actualité - 02.07.2022'
                },
                {
                    id: 3,
                    title: 'Participez aux veillées de prière pour la profession solennelle',
                    image: '/images/news/news-img-3.png',
                    date: 'Actualité - 21.06.2022'
                },
                {
                    id: 4,
                    title: 'Synode 2021-2023 : Pour une Église synodale',
                    image: '/images/news/news-img-4.png',
                    date: 'Actualité - 21.06.2022'
                },
                {
                    id: 5,
                    title: 'Lisez le dernier numéro des Echos de Saint-Maurice',
                    image: '/images/news/news-img-5.png',
                    date: 'Actualité - 21.06.2022'
                },
                {
                    id: 6,
                    title: 'Découvrez la crèche provençale de l\'Abbaye',
                    image: '/images/news/news-img-6.png',
                    date: 'Actualité - 21.06.2022'
                },
                {
                    id: 7,
                    title: 'Vernissage commun de 4 lieux emblématiques de Saint-Maurice',
                    image: '/images/news/news-img-7.png',
                    date: 'Actualité - 21.06.2022'
                },
                {
                    id: 8,
                    title: '"Contrastes" Photographies de Guillaume Allet & Alexandre Derivaz',
                    image: '/images/news/news-img-8.png',
                    date: 'Actualité - 21.06.2022'
                },
                {
                    id: 9,
                    title: 'Exposition sur le chanoine Bourban fermée temporairement',
                    image: '/images/news/news-img-9.png',
                    date: 'Actualité - 21.06.2022'
                },
            ]
        }
    }, 
}
</script>

<style>

</style>