<template>
  <section class="px-4">
    <div class="max-w-screen-2xl mx-auto">
        <div class="grid grid-cols-1 md:grid-cols-12 gap-7">
            <div class="md:col-span-3 lg:col-span-2 space-y-6 sm:space-y-10  flex  md:block justify-end -mt-16 md:-mt-0 -mr-4 md:-mr-0">
                <div class="path-two w-[140px] xl:w-[160px] h-[95px] xl:h-[112px] bg-brand-red flex justify-center items-center flex-col">
                    <p class="font-semibold text-base text-white">Sam</p>
                    <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">21</h3>
                    <p class="font-semibold text-base text-white">Août</p>
                </div>
                 <div class="space-y-5 hidden md:block">
                    <h5 class="text-sm font-medium text-brand-gray-900">Partager</h5> 
                    <ul class="flex gap-4 items-center">
                        <li><a href="#"><icon-facebook-circle></icon-facebook-circle></a></li>
                        <li><a href="#"><icon-twitter></icon-twitter></a></li>
                        <li><a href="#"><icon-linkedin></icon-linkedin></a></li>
                        <li><a href="#"><icon-mail></icon-mail></a></li>
                    </ul>
                 </div>
            </div>
            <div class="md:col-span-9 lg:col-span-8 space-y-8 sm:space-y-14 md:pt-12 lg:pt-16 xl:pt-20"> 
                <h2 class="text-[32px] md:text-[46px] leading-[1.1] text-dark font-lancelot">Festival Metanoia : un festival dans un cadre unique</h2>
                <div class="space-y-8">
                    <p class="text-base lg:text-[19px] text-dark leading-[1.7]">Du 11 au 17 juillet 2022 à lieu le Festival Metanoia, un lieu d’échanges et de rencontres qui cras a pulvinar dolor, vitae dignissim tellus. Vivamus vel dolor et nisl consectetur commodo. Praesent elementum, enim vel rutrum sagittis, elit augue viverra lacus, eu efficitur nibh eros in libero. Suspendisse potenti. Nulla efficitur hendrerit dapibus. </p>
                    <p class="text-base lg:text-[19px] text-dark leading-[1.7]">Donec sit amet velit quis leo maximus rutrum. Fusce ac lectus a nisl ornare ornare. Praesent hendrerit libero ac tincidunt condimentum. Suspendisse mi justo, cursus at varius quis, mollis blandit ipsum. Donec posuere, sapien quis rhoncus fermentum, ex nunc rutrum nisi, sit amet auctor nisi quam et lacus. Praesent ac lectus quis tortor pretium rhoncus. Donec sem mauris, tempus in diam vitae, pulvinar iaculis purus. Pellentesque rutrum, nisl at egestas aliquam, tellus justo tempor ipsum.  </p>
                    <p class="text-base lg:text-[19px] text-dark leading-[1.7]">Vitae molestie tortor ligula id felis. Donec id mattis nisl. Nam lacinia lacus vel neque dapibus, quis euismod mi consectetur.</p>
                </div>
            </div>
        </div>
    </div>
  </section>
</template>

<script>
export default {
    name: 'TextArea'
}
</script>

<style>

</style>