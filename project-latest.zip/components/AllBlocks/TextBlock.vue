<template>
  <section class="px-4 py-8 sm:py-14 lg:py-24 ">
        <div class="max-w-screen-2xl mx-auto">
            <div class="grid lg:grid-cols-12 sm:gap-7">
                <div class="lg:col-start-2 lg:col-span-10 space-y-14"> 
                    <h2 class="text-[32px] leading-[1.2] md:text-[42px] text-dark font-lancelot">Bloc de texte</h2>
                    <div class="lg:w-[880px] max-w-full mx-auto space-y-8"> 
                        <p class="text-base font-medium text-dark md:text-[19px] md:leading-[33px]"> 
                            Le parcours de visite est basé sur la lumière et l’image, symboles de la connaissance et de la foi. Il raconte une histoire exceptionnelle: celle d’une communauté religieuse vivante, miraculeusement préservée et constituant le témoignage unique d’une activité spirituelle et culturelle sans équivalent dans le monde occidental chrétien.
                            <br><br>
                            Consciente de l’importance mondiale de son patrimoine historique et culturel,
                             l’Abbaye de Saint-Maurice a décidé de l’ouvrir au public à l’occasion de son Jubilé. 
                             La visite de son Site culturel et patrimonial débute dans <a href="#" class="underline text-brand-red">la basilique</a> qui date du 17e siècle. 
                             Puis, un détour par le clocher vous permet de visiter <a href="#" class="underline text-brand-red">l’exposition temporaire</a>
                            . Vous parcourez ensuite <a href="#" class="underline text-brand-red">le site archéologique</a> des anciennes églises – aussi appelé site 
                            du Martolet – qui résulte de dix années de fouilles. Enfin, vous traversez les catacombes 
                            avant de découvrir  <a href="#" class="underline text-brand-red">le  Trésor abbatial.</a>
                            <br><br>
                            Pour vous accompagner dans l’exploration d’une histoire vieille de 1500 ans, 
                            un audioguide original vous est remis à l’entrée. En famille, laissez-vous guider par
                             l’audioguide ludique spécialement conçu pour les enfants ! Vous pouvez également profiter 
                             d’une <a href="#" class="underline text-brand-red">visite guidée</a> adaptée à votre groupe (sur <a href="#" class="underline text-brand-red">réservation</a> préalable).
                        </p> 
                    </div> 
                    <div class="pt-8 sm:pt-14">
                        <div class="aspect-w-16 aspect-h-9 ">
                            <iframe  src="https://www.youtube.com/embed/3NvgNgwfC9o" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name: 'TextBlock', 
}
</script>

<style>

</style>