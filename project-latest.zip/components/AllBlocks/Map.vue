<template>
    <section class="px-4 pt-8 sm:pt-14 pb-10 sm:pb-24">
        <div class="max-w-screen-2xl mx-auto space-y-6">
               <h2 class="text-[32px] hidden lg:block md:text-[42px] leading-[1.2] text-dark font-lancelot">Carte</h2>
            <figure>
                <img class="h-[400px] object-cover md:h-auto" src="/images/all-block/map.png" alt="map">
            </figure>
        </div>
    </section>
</template>

<script>
export default {
 name: 'Map'
}
</script>

<style>

</style>