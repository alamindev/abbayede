<template>
    <section class="px-4 py-8 lg:py-16">
    <div class="max-w-screen-2xl mx-auto">
        <div class="grid grid-cols-1 xl:grid-cols-12 gap-7">
            <div class="xl:col-start-2  xl:col-span-10 space-y-2 sm:space-y-6">
                 <h2 class="text-[32px] md:text-[42px] leading-[1.2]  max-w-[400px] md:max-w-none mx-auto text-dark font-lancelot text-left">horaires des messes</h2>
                 <div class="grid sm:border-y sm:divide-y divide-brand-gray  border-brand-gray grid-cols-1 sm:grid-cols-2">
                    <div class="flex gap-4 items-start py-4 sm:py-8 flex-col lg:flex-row">
                        <div class="path-two shrink-0 px-5 sm:px-10 py-3 bg-brand-red flex justify-center items-center flex-col">
                            <p class="font-semibold text-base text-white">Mer</p>
                            <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">16</h3>
                            <p class="font-semibold text-base text-white">Juillet</p>
                        </div>
                        <ul class="grid gap-2">
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">07:00</p>
                                <p class="text-[17px] font-medium text-dark">Office des lectures et laudes</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">12:00</p>
                                <p class="text-[17px] font-medium text-dark">Office du Milieu du Jour</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">18:00</p>
                                <p class="text-[17px] font-medium text-dark">Messe conventuelle et vêpres</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">20:00</p>
                                <p class="text-[17px] font-medium text-dark">Complies</p>
                            </li>
                        </ul>
                    </div>
                    <div class="flex gap-4 items-start py-4 sm:py-8 flex-col lg:flex-row">
                        <div class="path-two shrink-0 px-5 sm:px-10 py-3 bg-brand-red flex justify-center items-center flex-col">
                            <p class="font-semibold text-base text-white">Mer</p>
                            <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">17</h3>
                            <p class="font-semibold text-base text-white">Juillet</p>
                        </div>
                        <ul class="grid gap-2">
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">07:00</p>
                                <p class="text-[17px] font-medium text-dark">Office des lectures et laudes</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">12:00</p>
                                <p class="text-[17px] font-medium text-dark">Office du Milieu du Jour</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">18:00</p>
                                <p class="text-[17px] font-medium text-dark">Messe conventuelle et vêpres</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">20:00</p>
                                <p class="text-[17px] font-medium text-dark">Complies</p>
                            </li>
                        </ul>
                    </div>
                    <div class="flex gap-4 items-start py-4 sm:py-8 flex-col lg:flex-row">
                        <div class="path-two shrink-0 px-5 sm:px-10 py-3 bg-brand-red flex justify-center items-center flex-col">
                            <p class="font-semibold text-base text-white">Mer</p>
                            <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">18</h3>
                            <p class="font-semibold text-base text-white">Juillet</p>
                        </div>
                        <ul class="grid gap-2">
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">07:00</p>
                                <p class="text-[17px] font-medium text-dark">Office des lectures et laudes</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">12:00</p>
                                <p class="text-[17px] font-medium text-dark">Office du Milieu du Jour</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">18:00</p>
                                <p class="text-[17px] font-medium text-dark">Messe conventuelle et vêpres</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">20:00</p>
                                <p class="text-[17px] font-medium text-dark">Complies</p>
                            </li>
                        </ul>
                    </div>
                    <div class="flex gap-4 items-start py-4 sm:py-8 flex-col lg:flex-row">
                        <div class="path-two shrink-0 px-5 sm:px-10 py-3 bg-brand-red flex justify-center items-center flex-col">
                            <p class="font-semibold text-base text-white">Mer</p>
                            <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">19</h3>
                            <p class="font-semibold text-base text-white">Juillet</p>
                        </div>
                        <ul class="grid gap-2">
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">07:00</p>
                                <p class="text-[17px] font-medium text-dark">Office des lectures et laudes</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">12:00</p>
                                <p class="text-[17px] font-medium text-dark">Office du Milieu du Jour</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">18:00</p>
                                <p class="text-[17px] font-medium text-dark">Messe conventuelle et vêpres</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">20:00</p>
                                <p class="text-[17px] font-medium text-dark">Complies</p>
                            </li>
                        </ul>
                    </div>
                    <div class="flex gap-4 items-start py-4 sm:py-8 flex-col lg:flex-row">
                        <div class="path-two shrink-0 px-5 sm:px-10 py-3 bg-brand-red flex justify-center items-center flex-col">
                            <p class="font-semibold text-base text-white">Mer</p>
                            <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">20</h3>
                            <p class="font-semibold text-base text-white">Juillet</p>
                        </div>
                        <ul class="grid gap-2">
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">07:00</p>
                                <p class="text-[17px] font-medium text-dark">Office des lectures et laudes</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">12:00</p>
                                <p class="text-[17px] font-medium text-dark">Office du Milieu du Jour</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">18:00</p>
                                <p class="text-[17px] font-medium text-dark">Messe conventuelle et vêpres</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">20:00</p>
                                <p class="text-[17px] font-medium text-dark">Complies</p>
                            </li>
                        </ul>
                    </div>
                    <div class="flex gap-4 items-start py-4 sm:py-8 flex-col lg:flex-row">
                        <div class="path-two shrink-0 px-5 sm:px-10 py-3 bg-brand-red flex justify-center items-center flex-col">
                            <p class="font-semibold text-base text-white">Mer</p>
                            <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">21</h3>
                            <p class="font-semibold text-base text-white">Juillet</p>
                        </div>
                        <ul class="grid gap-2">
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">07:00</p>
                                <p class="text-[17px] font-medium text-dark">Office des lectures et laudes</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">12:00</p>
                                <p class="text-[17px] font-medium text-dark">Office du Milieu du Jour</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">18:00</p>
                                <p class="text-[17px] font-medium text-dark">Messe conventuelle et vêpres</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">20:00</p>
                                <p class="text-[17px] font-medium text-dark">Complies</p>
                            </li>
                        </ul>
                    </div>
                 </div>
                 <div class="pt-10 md:pt-20  xl:pt-28 ">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div class="bg-brand-creme path-four">
                            <div class="flex justify-between items-center">
                                <h3 class="text-dark pl-5 sm:pl-7 font-semibold text-xl md:text-2xl">Mardi</h3>
                                <div class="path-two shrink-0 px-5 sm:px-10 py-3 bg-brand-red flex justify-center items-center flex-col">
                                    <p class="font-semibold text-base text-white pt-1">Mer</p>
                                    <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">16</h3>
                                    <p class="font-semibold text-base text-white">Juillet</p>
                                </div>
                            </div>
                            <ul class="grid gap-4 px-8 pt-5 pb-10">
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">07:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Office des lectures et laudes</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">12:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Office du Milieu du Jour</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">18:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Messe conventuelle et vêpres</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">20:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Complies</a>
                                </li>
                            </ul>
                        </div>
                        <div class="bg-brand-creme path-four">
                            <div class="flex justify-between items-center">
                                <h3 class="text-dark pl-5 sm:pl-7 font-semibold text-xl md:text-2xl">Mercredi</h3>
                                <div class="path-two shrink-0 px-5 sm:px-10 py-3 bg-brand-red flex justify-center items-center flex-col">
                                    <p class="font-semibold text-base text-white pt-1">Mer</p>
                                    <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">17</h3>
                                    <p class="font-semibold text-base text-white">Juillet</p>
                                </div>
                            </div>
                            <ul class="grid gap-4 px-8 pt-5 pb-10">
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">07:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Office des lectures et laudes</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">12:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Office du Milieu du Jour</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">18:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Messe conventuelle et vêpres</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">20:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Complies</a>
                                </li>
                            </ul>
                        </div>
                        <div class="bg-brand-creme path-four">
                            <div class="flex justify-between items-center">
                                <h3 class="text-dark pl-5 sm:pl-7 font-semibold text-xl md:text-2xl">Jeudi</h3>
                                <div class="path-two shrink-0 px-5 sm:px-10 py-3 bg-brand-red flex justify-center items-center flex-col">
                                    <p class="font-semibold text-base text-white pt-1">Mer</p>
                                    <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">18</h3>
                                    <p class="font-semibold text-base text-white">Juillet</p>
                                </div>
                            </div>
                            <ul class="grid gap-4 px-8 pt-5 pb-10">
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">07:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Office des lectures et laudes</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">12:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Office du Milieu du Jour</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">18:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Messe conventuelle et vêpres</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">20:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Complies</a>
                                </li>
                            </ul>
                        </div>
                        <div class="bg-brand-creme path-four">
                            <div class="flex justify-between items-center">
                                <h3 class="text-dark pl-5 sm:pl-7 font-semibold text-xl md:text-2xl">Vendredi</h3>
                                <div class="path-two shrink-0 px-5 sm:px-10 py-3 bg-brand-red flex justify-center items-center flex-col">
                                    <p class="font-semibold text-base text-white pt-1">Mer</p>
                                    <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">19</h3>
                                    <p class="font-semibold text-base text-white">Juillet</p>
                                </div>
                            </div>
                            <ul class="grid gap-4 px-8 pt-5 pb-10">
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">07:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Office des lectures et laudes</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">12:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Office du Milieu du Jour</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">18:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Messe conventuelle et vêpres</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">20:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Complies</a>
                                </li>
                            </ul>
                        </div>
                        <div class="bg-brand-creme path-four">
                            <div class="flex justify-between items-center">
                                <h3 class="text-dark pl-5 sm:pl-7 font-semibold text-xl md:text-2xl">Samedi</h3>
                                <div class="path-two shrink-0 px-5 sm:px-10 py-3 bg-brand-red flex justify-center items-center flex-col">
                                    <p class="font-semibold text-base text-white pt-1">Mer</p>
                                    <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">20</h3>
                                    <p class="font-semibold text-base text-white">Juillet</p>
                                </div>
                            </div>
                            <ul class="grid gap-4 px-8 pt-5 pb-10">
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">07:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Office des lectures et laudes</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">12:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Office du Milieu du Jour</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">18:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Messe conventuelle et vêpres</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">20:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Complies</a>
                                </li>
                            </ul>
                        </div>
                        <div class="bg-brand-creme path-four">
                            <div class="flex justify-between items-center">
                                <h3 class="text-dark pl-5 sm:pl-7 font-semibold text-xl md:text-2xl">Dimanche</h3>
                                <div class="path-two shrink-0 px-5 sm:px-10 py-3 bg-brand-red flex justify-center items-center flex-col">
                                    <p class="font-semibold text-base text-white pt-1">Mer</p>
                                    <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">21</h3>
                                    <p class="font-semibold text-base text-white">Juillet</p>
                                </div>
                            </div>
                            <ul class="grid gap-4 px-8 pt-5 pb-10">
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">07:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Office des lectures et laudes</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">12:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Office du Milieu du Jour</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">18:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Messe conventuelle et vêpres</a>
                                </li>
                                <li class="flex gap-3 sm:gap-8 items-center">
                                    <span class="text-base md:text-[17px] font-semibold text-dark">20:00</span>
                                    <a href="#" class="underline text-base md:text-[17px] font-semibold text-dark">Complies</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="flex justify-center pt-12 sm:pt-16">
                        <nuxt-link  to="/" class="flex justify-start items-stretch group focus:none" >
                            <svg width="23"  height="44" viewBox="0 0 23 44" class="-mr-[2px] stroke-primary group-hover:fill-primary group-hover:stroke-primary" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M22 42.5L1 36.6227L1 7.74258L22 1.5"  stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
                            </svg>
                            <span class="border-y-2    font-medium text-dark group-hover:text-white bg-transparent group-hover:bg-primary group-hover:border-primary border-primary rounded-sm my-[0.3px] flex justify-center items-center">
                           Télécharger l’horaire
                            <sup> <icon-arrow-top-right></icon-arrow-top-right></sup>
                            </span>
                            <svg width="23" height="44" viewBox="0 0 23 44" class="-ml-[2px] stroke-primary group-hover:fill-primary group-hover:stroke-primary" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L22 7.37732V36.2574L1 42.5"  stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
                            </svg> 
                        </nuxt-link>
                    </div>
                 </div>
                 <div class="flex justify-center  pt-6 md:pt-14 lg:pt-24  pb-14 sm:pb-5">
                    <icon-flower></icon-flower>
                 </div>
            </div>
        </div>
    </div>
  </section>
</template>

<script>
export default {
    name: 'MassTimes'
}
</script>

<style>

</style>