<template>
    <section class="px-4 py-8 sm:py-12 lg:pt-24 lg:pb-14 ">
        <div class="max-w-screen-2xl mx-auto">
            <div class="grid lg:grid-cols-12 sm:gap-7">
                <div class="lg:col-start-2 lg:col-span-10">
                    <div class="space-y-3 md:space-y-5 ">
                        <div class="pr-12 sm:pr-0">
                            <h2 class="text-[32px] inline md:text-[42px] leading-[1.2] font-lancelot text-brand-red ">Pourquoi une Fondation ?</h2> 
                        </div>
                        <p class="text-brand-gray-900 text-xl font-normal sm:text-2xl !leading-[1.6] ">Le monastère de Saint-Maurice a été créé en 515 en vue d’honorer la mémoire de saint Maurice d’Agaune et de ses compagnons martyrs. Au fil du temps, ce monastère s’est transformé en ce qui est devenu l’Abbaye actuelle, au patrimoine culturel remarquable, où la spiritualité occupe une place importante et qui a également mission d’enseignement et d’aide humanitaire.</p>
                    </div>  
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name: 'Mission'
}
</script>

<style>

</style>