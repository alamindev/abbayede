<template>
  <section class="sm:px-4 py-8 sm:py-14 lg:py-24 ">
        <div class="max-w-screen-2xl mx-auto">
            <div class="grid lg:grid-cols-12 sm:gap-7">
                <div class="lg:col-start-2 lg:col-span-10">
                    <div class="space-y-3 md:space-y-5   md:pb-14 px-4 sm:px-0">
                        <div class="pr-12 sm:pr-0">
                            <h2 class="text-base sm:text-[32px] inline font-semibold uppercase leading-[1.2] text-brand-red ">Homélies à la basilique</h2>
                            <icon-verify class="inline mb-2"></icon-verify>
                        </div>
                        <p class="text-brand-gray-900 text-xl font-medium sm:text-2xl lg:text-[28px] !leading-[1.6] pr-5 sm:pr-0">Sur cette page, lisez et écoutez les homélie s prononcées à la Basilique.</p>
                    </div> 
                    <div class="pt-8 md:pt-2">
                        <div class="bg-brand-gray-800 bg-opacity-50">
                            <div class="px-4 lg:px-14 xl:px-24 py-4 sm:py-8">
                                <ul class="grid divide-y"> 
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">26.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">Vendredi Saint</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mgr Jean Scarcella</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">25.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">Dimanche des Rameaux</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mme Marie-Dominique Miniassian</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">25.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">5e Dimanche de Carême</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mgr Jean Scarcella</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">26.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">Vendredi Saint</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mgr Jean Scarcella</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">25.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">Dimanche des Rameaux</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mme Marie-Dominique Miniassian</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">25.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">5e Dimanche de Carême</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mgr Jean Scarcella</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">26.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">Vendredi Saint</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mgr Jean Scarcella</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">25.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">Dimanche des Rameaux</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mme Marie-Dominique Miniassian</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">25.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">5e Dimanche de Carême</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mgr Jean Scarcella</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">26.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">Vendredi Saint</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mgr Jean Scarcella</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">25.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">Dimanche des Rameaux</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mme Marie-Dominique Miniassian</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">25.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">5e Dimanche de Carême</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mgr Jean Scarcella</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">26.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">Vendredi Saint</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mgr Jean Scarcella</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">25.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">Dimanche des Rameaux</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mme Marie-Dominique Miniassian</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">25.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">5e Dimanche de Carême</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mgr Jean Scarcella</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">26.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">Vendredi Saint</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mgr Jean Scarcella</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">25.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">Dimanche des Rameaux</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mme Marie-Dominique Miniassian</p>
                                    </li>
                                    <li class="grid md:grid-cols-12 py-3 sm:py-4 gap-3 md:gap-14">
                                        <p class="text-base md:text-[19px] font-medium text-[#828282] w-[110px] md:w-[130px] col-span-2">25.05.2022</p>
                                        <a href="#" class="underline text-dark text-base md:text-[19px] font-medium col-span-5">5e Dimanche de Carême</a>
                                        <p class=" text-dark text-base md:text-[19px] font-medium col-span-5">Mgr Jean Scarcella</p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name: 'MainArea',
   
}
</script>

<style>

</style>