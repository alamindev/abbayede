<template>
    <section class="px-4 py-8 lg:py-16">
    <div class="max-w-screen-2xl mx-auto">
        <div class="grid grid-cols-1 xl:grid-cols-12 gap-7">
            <div class="xl:col-start-2  xl:col-span-10 space-y-2 sm:space-y-6">
                 <h2 class="text-[32px] md:text-[42px] leading-[1.2]  max-w-[400px] md:max-w-none mx-auto text-dark font-lancelot text-left">horaires des messes</h2>
                 <div class="grid sm:border-y sm:divide-y divide-brand-gray  border-brand-gray grid-cols-1 sm:grid-cols-2">
                    <div class="flex gap-4 items-start py-4 sm:py-8 flex-col lg:flex-row">
                        <div class="path-two shrink-0 px-10 py-6 bg-brand-red flex justify-center items-center flex-col">
                            <p class="font-semibold text-base text-white">Mer</p>
                            <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">16</h3>
                            <p class="font-semibold text-base text-white">Juillet</p>
                        </div>
                        <ul class="grid gap-2">
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">07:00</p>
                                <p class="text-[17px] font-medium text-dark">Office des lectures et laudes</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">12:00</p>
                                <p class="text-[17px] font-medium text-dark">Office du Milieu du Jour</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">18:00</p>
                                <p class="text-[17px] font-medium text-dark">Messe conventuelle et vêpres</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">20:00</p>
                                <p class="text-[17px] font-medium text-dark">Complies</p>
                            </li>
                        </ul>
                    </div>
                    <div class="flex gap-4 items-start py-4 sm:py-8 flex-col lg:flex-row">
                        <div class="path-two shrink-0 px-10 py-6 bg-brand-red flex justify-center items-center flex-col">
                            <p class="font-semibold text-base text-white">Mer</p>
                            <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">17</h3>
                            <p class="font-semibold text-base text-white">Juillet</p>
                        </div>
                        <ul class="grid gap-2">
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">07:00</p>
                                <p class="text-[17px] font-medium text-dark">Office des lectures et laudes</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">12:00</p>
                                <p class="text-[17px] font-medium text-dark">Office du Milieu du Jour</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">18:00</p>
                                <p class="text-[17px] font-medium text-dark">Messe conventuelle et vêpres</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">20:00</p>
                                <p class="text-[17px] font-medium text-dark">Complies</p>
                            </li>
                        </ul>
                    </div>
                    <div class="flex gap-4 items-start py-4 sm:py-8 flex-col lg:flex-row">
                        <div class="path-two shrink-0 px-10 py-6 bg-brand-red flex justify-center items-center flex-col">
                            <p class="font-semibold text-base text-white">Mer</p>
                            <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">18</h3>
                            <p class="font-semibold text-base text-white">Juillet</p>
                        </div>
                        <ul class="grid gap-2">
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">07:00</p>
                                <p class="text-[17px] font-medium text-dark">Office des lectures et laudes</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">12:00</p>
                                <p class="text-[17px] font-medium text-dark">Office du Milieu du Jour</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">18:00</p>
                                <p class="text-[17px] font-medium text-dark">Messe conventuelle et vêpres</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">20:00</p>
                                <p class="text-[17px] font-medium text-dark">Complies</p>
                            </li>
                        </ul>
                    </div>
                    <div class="flex gap-4 items-start py-4 sm:py-8 flex-col lg:flex-row">
                        <div class="path-two shrink-0 px-10 py-6 bg-brand-red flex justify-center items-center flex-col">
                            <p class="font-semibold text-base text-white">Mer</p>
                            <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">19</h3>
                            <p class="font-semibold text-base text-white">Juillet</p>
                        </div>
                        <ul class="grid gap-2">
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">07:00</p>
                                <p class="text-[17px] font-medium text-dark">Office des lectures et laudes</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">12:00</p>
                                <p class="text-[17px] font-medium text-dark">Office du Milieu du Jour</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">18:00</p>
                                <p class="text-[17px] font-medium text-dark">Messe conventuelle et vêpres</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">20:00</p>
                                <p class="text-[17px] font-medium text-dark">Complies</p>
                            </li>
                        </ul>
                    </div>
                    <div class="flex gap-4 items-start py-4 sm:py-8 flex-col lg:flex-row">
                        <div class="path-two shrink-0 px-10 py-6 bg-brand-red flex justify-center items-center flex-col">
                            <p class="font-semibold text-base text-white">Mer</p>
                            <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">20</h3>
                            <p class="font-semibold text-base text-white">Juillet</p>
                        </div>
                        <ul class="grid gap-2">
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">07:00</p>
                                <p class="text-[17px] font-medium text-dark">Office des lectures et laudes</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">12:00</p>
                                <p class="text-[17px] font-medium text-dark">Office du Milieu du Jour</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">18:00</p>
                                <p class="text-[17px] font-medium text-dark">Messe conventuelle et vêpres</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">20:00</p>
                                <p class="text-[17px] font-medium text-dark">Complies</p>
                            </li>
                        </ul>
                    </div>
                    <div class="flex gap-4 items-start py-4 sm:py-8 flex-col lg:flex-row">
                        <div class="path-two shrink-0 px-10 py-6 bg-brand-red flex justify-center items-center flex-col">
                            <p class="font-semibold text-base text-white">Mer</p>
                            <h3 class="text-[32px] xl:text-[40px] leading-[.9] font-semibold text-white">21</h3>
                            <p class="font-semibold text-base text-white">Juillet</p>
                        </div>
                        <ul class="grid gap-2">
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">07:00</p>
                                <p class="text-[17px] font-medium text-dark">Office des lectures et laudes</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">12:00</p>
                                <p class="text-[17px] font-medium text-dark">Office du Milieu du Jour</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">18:00</p>
                                <p class="text-[17px] font-medium text-dark">Messe conventuelle et vêpres</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <p class="text-[17px] font-semibold text-brand-gray-900">20:00</p>
                                <p class="text-[17px] font-medium text-dark">Complies</p>
                            </li>
                        </ul>
                    </div>
                 </div>
                 <div class="flex justify-center  pt-6 md:pt-14 lg:pt-24  pb-14 sm:pb-5">
                    <icon-flower></icon-flower>
                 </div>
            </div>
        </div>
    </div>
  </section>
</template>

<script>
export default {
    name: 'MassTimes'
}
</script>

<style>

</style>