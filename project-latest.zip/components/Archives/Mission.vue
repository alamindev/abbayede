<template>
    <section class="px-4 pt-8 pb-5 sm:pt-14 sm:pb-7 lg:pt-24 lg:pb-10 ">
        <div class="max-w-screen-2xl mx-auto">
            <div class="grid lg:grid-cols-12 sm:gap-7">
                <div class="lg:col-start-2 lg:col-span-10">
                    <div class="space-y-3 md:space-y-5   md:pb-14">
                        <div class="pr-12 sm:pr-0">
                            <h2 class="text-base sm:text-[32px] inline   leading-[1.2] font-semibold uppercase text-brand-red ">Notre mission</h2>
                            <icon-verify class="inline mb-2"></icon-verify>
                        </div>
                        <p class="text-brand-gray-900 text-xl  font-normal sm:text-2xl !leading-[1.6]">Consciente du fait que sa mémoire est un bien collectif, l'Abbaye de Saint-Maurice entend ouvrir ses archives à tous ceux, chercheurs émérites ou simples amateurs que cela intéresse. C'est pourquoi la Fondation des archives historiques de l'Abbaye de Saint-Maurice se donne pour mission d'appuyer les autorités de l'Abbaye dans leurs efforts d'ouverture des archives.</p>
                    </div>  
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name: 'Mission'
}
</script>

<style>

</style>