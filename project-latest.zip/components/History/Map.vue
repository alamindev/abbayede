<template>
    <section class="px-4 pt-8 sm:pt-14 pb-10 sm:pb-24">
        <div class="max-w-screen-2xl mx-auto">
            <figure>
                <img src="/images/history/map.png" alt="map">
            </figure>
        </div>
    </section>
</template>

<script>
export default {
 name: 'Map'
}
</script>

<style>

</style>