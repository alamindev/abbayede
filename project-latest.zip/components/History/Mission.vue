<template>
    <section class="px-4 py-8 sm:py-12 lg:pt-24 lg:pb-5 ">
        <div class="max-w-screen-2xl mx-auto">
            <div class="grid lg:grid-cols-12 sm:gap-7">
                <div class="lg:col-start-2 lg:col-span-10">
                    <div class="space-y-3 md:space-y-5 ">
                        <div class="pr-12 sm:pr-0">
                            <h2 class="text-base sm:text-[32px] inline font-semibold leading-[1.2] text-brand-red uppercase">une histoire millénaire</h2> 
                            <icon-verify class="inline mb-2"></icon-verify>
                        </div>
                        <p class="text-brand-gray-900 text-xl font-normal sm:text-2xl md:text-[28px] !leading-[1.6] ">L’histoire d’Agaune commence autour de l’an 300 avec le martyre de saint Maurice et de ses compagnons de la Légion thébaine. Venus d’Égypte, ces soldats chrétiens font partie de l’armée de Maximien. Toujours en phase avec le monde qui l’entoure et ses besoins, l’Abbaye de Saint-Maurice regarde aujourd’hui son passé avec gratitude et envisage son avenir avec confiance.</p>
                    </div>  
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name: 'Mission'
}
</script>

<style>

</style>