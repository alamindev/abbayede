<template>
    <section class="px-4 py-8 sm:py-12   lg:pb-14 ">
        <div class="max-w-screen-2xl mx-auto">
            <div class="max-w-[880px] mx-auto">
                <h2 class="text-dark font-lancelot text-[32px] md:text-[46px] pb-8">Lieux dédiés</h2>
                <p class="text-base md:text-[19px] text-dark font-medium">
                    Maurice est devenu le saint patron de centaines de villes, paroisses, églises et institutions en Europe et dans le monde. On dénombre ainsi de très nombreuses églises dédiées à Saint Maurice.
                    <br><br>
                    Basiliques, cathédrales, églises paroissiales, simples églises ou modestes chapelles, au centre des villes ou des villages, en plaine ou dans les montagnes, elles témoignent, dans tous les styles, du rayonnement du martyr dans la chrétienté.
                        <br><br>
                    Elles sont catholiques, mais aussi coptes orthodoxes, évangéliques-luthériennes ou anglicanes, entre la Californie et la Nouvelle-Calédonie.
                </p>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name: 'Mission'
}
</script>

<style>

</style>