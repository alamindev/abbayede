<template>
  <section class="sm:px-4 py-8 sm:py-14 lg:py-24 ">
        <div class="max-w-screen-2xl mx-auto">
            <div class="grid lg:grid-cols-12 sm:gap-7">
                <div class="lg:col-start-2 lg:col-span-10 space-y-14 px-4 sm:px-0">
                    <p class="font-medium text-brand-gray">26.05.2022</p>
                    <h2 class="text-[32px] leading-[1.2] md:text-[46px] text-dark font-lancelot">Solennité de l'Ascension du Seigneur</h2>
                    <div class="lg:w-[880px] max-w-full mx-auto space-y-8">
                        <h3 class="font-medium text-dark text-base md:text-[19px]">Mes sœurs, mes frères,</h3>
                        <p class="text-base font-medium text-dark md:text-[19px] md:leading-[33px]"> 
                            L’Ascension du Christ a fait la une de multiples toiles de peintres tout aussi fameux les uns que les autres à travers les siècles, certainement aussi de bandes dessinées et peut-être même de films… De fait, l’Ascension du Christ est a priori comprise comme une élévation de Jésus en son corps d’homme vers le ciel, et c’est donc quelque chose de parfaitement visuel. Il est vrai que nous n’avons aucune peine à nous imaginer la scène décrite dans les Actes des Apôtres : “Après ces paroles, tandis que les Apôtres le regardaient, il s’éleva, et une nuée vint le soustraire à leurs yeux”.
                            <br><br>
                            Mais voici que le mot ‘nuée’ va nous empêcher de nous arrêter au seul fait physique que nous sommes en train de décrire. Nous le savons, dans l’Écriture Sainte, la nuée est toujours signe d’une manifestation de Dieu ; la nuée qui conduisit les Hébreux à travers le désert, celle qui annonçait la présence de Dieu devant la tente de la Rencontre, celle qui enveloppa Pierre, Jean et Jacques sur le mont de la Transfiguration, et tant d’autres exemples encore que nous pourrions citer. Je lis donc ici, que cette élévation du Christ s’est accompagnée de la présence de Dieu. Et je comprends que par son Ascension Jésus retrouvait sa place dans la sphère divine d’où il était venu, un soir de Noël.
                            <br><br> 
                            Dès lors, frères et sœurs, il nous faut quitter l’aspect physique de l’événement pour entrer dans un autre type d’aspect, mystique celui-ci, un aspect qui relève du mystère. L’Ascension de Jésus n’est pas un petit tour en montgolfière – passez-moi cette expression –, et d’ailleurs les deux hommes en vêtements blancs qui côtoyaient les Apôtres ne s’y ont pas trompés : “Galiléens, pourquoi restez-vous là à regarder le ciel ? Ce Jésus qui a été enlevé au ciel d’auprès de vous – c’est-à-dire pris dans la nuée, dans les bras de son Père en quelque sorte – [ce Jésus] viendra de la même manière que vous l’avez vu s’en aller vers le ciel” ; en fait l’Ascension de Jésus est un signe de notre salut. Car c’est bien pour cela que le Père l’avait envoyé sur terre au milieu des hommes pour les sauver de leur péché, donc nous aussi encore aujourd’hui. Oui, l’Ascension parle du mystère de notre salut, frères et sœurs.
                            <br><br>
                            Cet événement incroyable où Jésus se dérobe à nos yeux pour se manifester au monde à travers nous dans la force de l’Esprit qu’il viendra donner aux Apôtres et à toute l’humanité de tous les temps, cet événement est indissociable de la résurrection du Christ. 
                            La Lettre aux Hébreux nous l’explique très en détail, vous l’avez entendue. L’auteur nous rappelle que le Christ a souffert sa passion en un sacrifice sanglant une fois pour toutes, afin de détruire notre péché, c’est-à-dire nous sauver. Et d’utiliser alors cette image extraordinaire, souvenez-vous : “C’est avec assurance que nous pouvons entrer dans le véritable sanctuaire grâce au sang de Jésus : nous avons là un chemin nouveau et vivant qu’il a inauguré en franchissant le rideau du sanctuaire”. Oui, frères et sœurs, Jésus, dans sa mort et sa résurrection, est devenu le vrai sanctuaire, faisant passer le peuple du temple de l’ancienne alliance où l’on offrait les sacrifices, pour aller, outre le rideau du saint des saints, rejoindre son Père par son sacrifice sur la Croix, devenant lui-même le sanctuaire de la gloire de Dieu. Ce rideau dont saint Matthieu rapporte dans son Évangile qu’il se partagea au moment de la mort du Christ : eh bien c’est la porte ouvrant sur la nouvelle Alliance ! La porte de notre salut, frères et sœurs, la porte au bout du “chemin nouveau” que le Christ a tracé devant nous et sur lequel où nous pouvons mettre nos pas dans les siens.
                        </p> 
                    </div>
                    <div class="bg-brand-creme path-three">
                        <div class="lg:w-[880px] max-w-full mx-auto px-4 py-6">
                        <div class="flex justify-start pb-2">
                            <icon-comma-top></icon-comma-top>
                        </div>
                            <h2 class="text-xl md:text-2xl text-dark font-lancelot lg:leading-[0.9]">L’Ascension de Jésus n’est pas une évasion de notre condition humaine, mais une promesse de demeurer avec tous les hommes jusqu’à la fin du monde</h2>
                         <div class="flex justify-end pt-2">
                            <icon-comma-bottom></icon-comma-bottom>
                        </div>
                        </div>
                    </div>
                    <div class="lg:w-[880px] max-w-full mx-auto space-y-8">
                        <p class="text-base font-medium text-dark md:text-[19px] md:leading-[33px]"> 
                            Alors, comment comprendre l’Ascension en son mystère ineffable ? Nous venons d’essayer d’entrevoir l’intimité qui relie l’Ascension de Jésus et sa Résurrection, c’est-à-dire comme un mouvement unique l’emportant dans la gloire. Ainsi le mystère que l’Ascension célèbre est bien celui de l’accomplissement de la Pâque du Christ dans son Corps total, c’est-à-dire son Église, dont il avait donné les clés à Pierre afin qu’il affermisse ses frères, et conduise et paisse le troupeau. Qu’est-ce que cela veut dire ? Eh bien que nous, frères et sœurs, nous sommes complètement immergés dans ce mystère, puisque nous sommes l’Église, le Corps mystique du Christ. Et donc l’Ascension de Jésus, n’est pas l’élévation de son corps de la terre au ciel, bien que la réalité physique soit celle-ci, mais en revanche l’ascension de son être dans nos âmes et nos cœurs. Ainsi, Jésus nous prépara-t-il à recevoir l’Esprit saint promis en nous faisant participants de son propre mystère, nous demandant ainsi de continuer à révéler sa présence dans le monde.
                            <br><br>
                                Parce que nous le savons maintenant, l’Ascension de Jésus n’est pas une évasion de notre condition humaine, mais une promesse de demeurer avec tous les hommes jusqu’à la fin du monde. Et sa présence en nous advient d’une manière particulière à l’heure de son Ascension, parce qu’il souhaite que nous devenions missionnaires, que nous prenions le relais de son Évangile. C’est pourquoi les anges dirent aux Apôtres, tout comme à nous aujourd’hui, que le Seigneur reviendra et qu’il ne sert donc à rien de contempler le ciel pour nous évader de notre mission de chrétiens. Ils ont donc renvoyé les Apôtres à leurs tâches, qui sont les mêmes pour nous aujourd’hui, à savoir annoncer l’Évangile en le vivant et, par là même, en rendant présent Jésus, totalement actif et aimant au cœur du monde. Le baptême que Jésus a promis à ses Apôtres avant de les quitter, c’est celui que nous avons reçu, et que nous devons accepter en intégrant au tréfonds de nous-mêmes les propres mots de Jésus à ses Apôtres : “Vous allez recevoir une force quand le Saint Esprit viendra sur vous ; vous serez alors mes témoins à Jérusalem, dans toute la Judée et la Samarie, et jusqu’aux extrémités de la terre“.
                                <br><br>
                                    C’est à partir de là que commence notre marche vers notre salut. Jésus, dans sa Résurrection et son Ascension nous prépare à nous rendre participants de sa divinité. Et, en attendant son retour, comme il l’a annoncé et comme l’a répété l’auteur de la Lettre aux Hébreux : “il apparaîtra une seconde fois, non plus à cause du péché, mais pour le salut de ceux qui l’attendent”, nous avons à travailler à préparer notre âme pour la vie éternelle. Jésus est mort pour nous sauver, et il est monté au ciel pour nous préparer une place. Mais il ne le fera pas sans nous ; c’est pourquoi Jésus fait son Ascension dans notre âme et notre cœur, en nous envoyant l’Esprit qui prend demeure en nous et qui nous guidera sur le chemin de la vie. Un chemin de missionnaires, une vie de témoins, voilà ce à quoi nous engage l’Ascension de Jésus. Il ne part pas pour nous laisser, il quitte cette terre pour mieux demeurer en nous, afin que nous continuions, comme il l’a fait, et comme il nous a dit de le faire, à savoir proclamer la conversion pour le pardon des péchés en son nom, et nous enjoignant à en être les témoins.
                                <br><br>
                                    Ainsi soit-il !
                                    Mgr Jean Scarcella
                        </p> 
                    </div>
                    <div class="aspect-w-16 aspect-h-9 -mx-4 md:-mx-0">
                        <iframe  src="https://www.youtube.com/embed/3NvgNgwfC9o" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                     <div class="flex flex-wrap gap-4 items-center xl:pl-24 ">
                            <nuxt-link  to="/" class="flex justify-start items-stretch group focus:none" >
                                <svg width="23"  height="44" viewBox="0 0 23 44" class="-mr-[2px] stroke-primary group-hover:fill-primary group-hover:stroke-primary" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M22 42.5L1 36.6227L1 7.74258L22 1.5"  stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
                                </svg>
                                <span class="border-y-2    font-medium text-dark group-hover:text-white bg-transparent group-hover:bg-primary group-hover:border-primary border-primary rounded-sm my-[0.3px] flex justify-center items-center">
                                   Télécharger l’homélie
                                    <sup><icon-arrow-top-right></icon-arrow-top-right></sup>
                                </span>
                                <svg width="23" height="44" viewBox="0 0 23 44" class="-ml-[2px] stroke-primary group-hover:fill-primary group-hover:stroke-primary" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 1.5L22 7.37732V36.2574L1 42.5"  stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
                                </svg> 
                            </nuxt-link>
                            <nuxt-link  to="/" class="flex justify-start items-stretch group focus:none" >
                                <svg width="23"  height="44" viewBox="0 0 23 44" class="-mr-[2px] stroke-primary group-hover:fill-primary group-hover:stroke-primary" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M22 42.5L1 36.6227L1 7.74258L22 1.5"  stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
                                </svg>
                                <span class="border-y-2    font-medium text-dark group-hover:text-white bg-transparent group-hover:bg-primary group-hover:border-primary border-primary rounded-sm my-[0.3px] flex justify-center items-center">
                                Lien vers d’autres ressources
                                <sup> <icon-arrow-top-right></icon-arrow-top-right></sup>
                                </span>
                                <svg width="23" height="44" viewBox="0 0 23 44" class="-ml-[2px] stroke-primary group-hover:fill-primary group-hover:stroke-primary" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 1.5L22 7.37732V36.2574L1 42.5"  stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
                                </svg> 
                            </nuxt-link>
                        </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name: 'MainArea', 
}
</script>

<style>

</style>