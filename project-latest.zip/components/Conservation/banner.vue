<template>
  <section class="px-4 pb-14 pt-64 md:pt-80  relative">
    <img src="/images/conservation/img-1.png" class="absolute inset-0 h-full object-cover w-full object-center" alt="img-1.png"> 
    <div class="absolute inset-0 w-full h-full bg-dark bg-opacity-20"></div>
    <div class="max-w-screen-2xl mx-auto relative z-20 ">
        <h1 class="text-[42px] md:text-[64px] lg:text-[86px] leading-none font-lancelot text-white ">Conservation et <br> restauration</h1>
    </div>
  </section>
</template>

<script>
export default {
    name: 'conservationBanner'
}
</script>

<style>

</style>