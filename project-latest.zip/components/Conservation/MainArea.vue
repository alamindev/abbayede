<template>
    <section class="px-4 pb-12 sm:pb-20 lg:pb-28 ">
        <div class="max-w-screen-2xl mx-auto">
            <div class="grid lg:grid-cols-12 sm:gap-7">
                <div class="lg:col-start-2 lg:col-span-10 space-y-7 md:space-y-14">
                    <h2 class="text-[32px] md:text-[42px] leading-[1.2] font-lancelot text-dark ">Restauration des chasses</h2> 
                    <div class="xl:px-24 space-y-6">
                        <figure class="space-y-8">
                            <img src="/images/conservation/img-2.png" alt="img-2.png">
                            <figcaption class="font-medium italic text-brand-gray-900 text-base lg:text-[17px]">Vue 3/4 de la Grande châsse de saint Maurice avant restauration © Jean-Yves Glassey et Michel Martinez</figcaption>
                        </figure>
                       <p class="text-base lg:text-[19px] text-[#282828] leading-[1.7] font-medium"> Ce projet interdisciplinaire d’une durée de 7 ans vise à l’étude et à la conservation-restauration de deux châsses du Trésor abbatial : <a href="#" class="underline text-brand-red">la Grande châsse de saint Maurice </a> et <a href="#" class="underline text-brand-red">la Châsse de l’abbé Nantelme</a>, deux des reliquaires les plus prestigieux du <a href="#" class="underline text-brand-red">Trésor de l’Abbaye</a> de Saint-Maurice d’Agaune, fondée en 515.
                        <br><br>
                        L’étude conjointe de la technique, de l’histoire, de l’iconographie, confrontée à l’interprétation des altérations, devrait permettre de retracer, sur la longue durée, la biographie de ces reliquaires et d’en identifier l’origine ainsi que le contexte de mise en oeuvre. Les études récentes, commencées en 2017, indiquent que les deux reliquaires sont contemporains, d’où la nécessité d’une étude conjointe.
                        <br><br>
                        Après plusieurs siècles de vénération et malgré une protection constante de la communauté des chanoines, ces reliquaires souffrent aujourd’hui de dégradations dues au temps et à l’usage. <a href="#" class="underline text-brand-red">Un traitement de restauration</a> est nécessaire pour assurer la transmission de ce patrimoine sacré aux générations futures.
                        </p>
                        <figure class="space-y-8">
                            <img src="/images/conservation/img-3.png" alt="img-3.png">
                            <figcaption class="font-medium italic text-brand-gray-900 text-base lg:text-[17px]">Vue 3/4 de la châsse de l’Abbé Nantelme avant restauration © Jean-Yves Glassey et Michel Martinez</figcaption>
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name: 'ConservationMainArea'
}
</script>

<style>

</style>