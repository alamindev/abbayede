<template>
    <section class="px-4 py-8 sm:py-12 lg:pt-24 lg:pb-14 ">
        <div class="max-w-screen-2xl mx-auto">
            <div class="grid lg:grid-cols-12 sm:gap-7">
                <div class="lg:col-start-2 lg:col-span-10">
                    <div class="space-y-3 md:space-y-5 ">
                        <div class="pr-12 sm:pr-0">
                            <h2 class="text-base sm:text-[32px] inline   leading-[1.2] font-semibold uppercase text-brand-red ">Un devoir de conservation</h2> 
                            <icon-verify class="inline mb-2"></icon-verify>
                        </div>
                        <p class="text-brand-gray-900 text-xl font-normal sm:text-2xl !leading-[1.6] ">Des traces historiques à conserver, des altérations à stabiliser et une splendeur à restaurer. Un sérieux travail en ce sens a déjà été entrepris par le récent dispositif de la salle du trésor et l’équipe en place, mais cela nécessite encore des améliorations et une vigilance constante.</p>
                    </div>  
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name: 'Mission'
}
</script>

<style>

</style>